package com.finale.notewordy;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {
    private dataHelper vocBase;
    private ArrayList<vocabulary> allVocab = new ArrayList<vocabulary>();
    private ArrayList<String> vocword = new ArrayList<String>();
    private ArrayList<String> voctense = new ArrayList<String>();
    private ArrayList<String> vocdef = new ArrayList<String>();
    public final static String STARTING_ID = "com.finale.notewordy.BEGIN_ID";
    public final static String CURVRS = "1.0.0";
    public final static String VRS_KEY = "lastloginversion";
    public final static String VRS_FILE = "prevVrs";
    public final static String DATE_KEY = "lastlogindate";
    public final static String DATE_FILE = "prevdate";
    private SharedPreferences prevVers;
    private SharedPreferences.Editor editVers;
    private SharedPreferences datePref;
    private SharedPreferences.Editor editDate;
    private String date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setSavedData();
        vocBase = new dataHelper(this);
        if(vocBase.getT1Data().getCount() == 0 && vocBase.getT2Data().getCount() == 0){
            Intent intent = new Intent(this, dailyService.class);
            startService(intent);
            makeDatabase();
            makeDateFile();
            makeVerFile();
            breakVocab(allVocab);
        }
        if(!(CURVRS.equals(prevVers.getString(VRS_KEY, "")))){
            editVers.remove(VRS_KEY);
            editVers.commit();
            editVers.putString(VRS_KEY, CURVRS);
            editDate.commit();
            //Make sure to actually write an update method, if ever necessary!
            updateAllData();
        }
        grabDatabase();
        setContentView(R.layout.activity_main);
        //Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        //T1btn = (Button) findViewById(R.id.unusedbtn);
        //T2btn = (Button) findViewById(R.id.usedbtn);
        //viewT1();
        //viewT2();
    }

    private void updateAllData() {}

    private void setSavedData() {
        datePref = getSharedPreferences(DATE_FILE, MODE_PRIVATE);
        editDate = datePref.edit();
        date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        prevVers = getSharedPreferences(VRS_FILE, MODE_PRIVATE);
        editVers = prevVers.edit();
    }

    private void makeVerFile() {
        editVers.putString(VRS_KEY, CURVRS);
        editDate.commit();
    }

    private void makeDateFile() {
        editDate.putString(DATE_KEY, date);
        editDate.commit();
        editDate.putInt(dailyWord.DAILY_ID, 58);
        editDate.commit();
    }

    private void breakVocab(ArrayList<vocabulary> masterlist){
        for (int k = 0; k < allVocab.size(); k++){
            vocabulary temp = allVocab.get(k);
            vocword.add(temp.getWord());
            voctense.add(temp.getTense());
            vocdef.add(temp.getDefinition());
        }
    }

    private void grabDatabase() {
        Cursor result = vocBase.getT1Data();
        while (result.moveToNext()){
            vocword.add(result.getString(result.getColumnIndex(vocBase.COL_2)));
            voctense.add(result.getString(result.getColumnIndex(vocBase.COL_3)));
            vocdef.add(result.getString(result.getColumnIndex(vocBase.COL_4)));
        }
    }

    private void makeDatabase() {
        AssetManager tempam = this.getAssets();
        try {
            InputStream tempis = tempam.open("masterWords.txt");
            if (tempis != null){
                InputStreamReader translator = new InputStreamReader(tempis);
                BufferedReader reader = new BufferedReader(translator);
                String line = "";
                int idnumber = 1;
                while (true){
                    line = reader.readLine();
                    if(line == null){
                        break;
                    }
                    allVocab.add(lineToVocab(line, idnumber));
                    idnumber++;
                }
            }
            for(int k = 0; k < allVocab.size(); k++){
                vocabulary temp = allVocab.get(k);
                vocBase.insertDataUnused(temp.getWord(), temp.getTense(), temp.getDefinition());
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private vocabulary lineToVocab(String text, int identity) {
        Scanner sc = new Scanner(text);
        int ID = identity;
        String vocWord = sc.next();
        String vocTense = sc.next();
        String vocDefinition = "";
        String tempDef = "";
        tempDef += sc.next();
        int tempCount = 0;
        //Checking for character above \, not a capital i or lowercase L
        while (sc.hasNext() && !(tempDef.equals("|"))){
            if (tempCount != 0){
                vocDefinition += " ";
            }
            vocDefinition += tempDef;
            tempDef = sc.next();
            tempCount++;
        }
        vocabulary debug = new vocabulary(ID, vocWord, vocTense, vocDefinition);
        return debug;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void toDictionary(View view){
        Intent intent = new Intent(getApplicationContext(), Dictionary.class);
        intent.putExtra(STARTING_ID, 1);
        Dictionary.vocword = vocword;
        Dictionary.voctense = voctense;
        Dictionary.vocdef = vocdef;
        startActivity(intent);
    }

    public void toDailyWord(View view) {
        Intent intent = new Intent (this, dailyWord.class);
        startActivity(intent);
    }

    public void toNotes(View view) {
        Intent intent = new Intent (this, NotesActivity.class);
        startActivity(intent);
    }

    /*public void viewT1(){
        T1btn.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        Cursor result = vocBase.getT1Data();
                        if (result.getCount() == 0){
                            showMessage("Error", "Nothing found");
                            return;
                        }
                        StringBuffer buffer = new StringBuffer();
                        while (result.moveToNext()){
                            buffer.append("ID: " + result.getString(result.getColumnIndex(vocBase.COL_1)) + "\n");
                            buffer.append("WORD: " + result.getString(result.getColumnIndex(vocBase.COL_2)) + "\n");
                            buffer.append("TENSE: " + result.getString(result.getColumnIndex(vocBase.COL_3)) + "\n");
                            buffer.append("DEFINITION: " + result.getString(result.getColumnIndex(vocBase.COL_4)) + "\n\n");
                        }
                        showMessage("Data", buffer.toString());
                    }
                }
        );
    }

    public void viewT2(){
        T2btn.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        Cursor result = vocBase.getT2Data();
                        if (result.getCount() == 0){
                            showMessage("Error", "Nothing found");
                            return;
                        }
                        StringBuffer buffer = new StringBuffer();
                        while (result.moveToNext()){
                            buffer.append("ID: " + result.getString(result.getColumnIndex(vocBase.COL_1)) + "\n");
                            buffer.append("WORD: " + result.getString(result.getColumnIndex(vocBase.COL_2)) + "\n");
                            buffer.append("TENSE: " + result.getString(result.getColumnIndex(vocBase.COL_3)) + "\n");
                            buffer.append("DEFINITION: " + result.getString(result.getColumnIndex(vocBase.COL_4)) + "\n\n");
                        }
                        showMessage("Data", buffer.toString());
                    }
                }
        );
    }

    public void showMessage(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
   */
}
