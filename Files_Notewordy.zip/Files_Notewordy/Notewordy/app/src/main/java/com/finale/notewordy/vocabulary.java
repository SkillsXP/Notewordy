package com.finale.notewordy;

/**
 * Created by shreyas on 5/21/16.
 */
public class vocabulary {

    private int ID = 0;
    private String word = null;
    private String tense = null;
    private String definition = null;

    public vocabulary (int identification_number, String vocword, String vocabtense, String vocdef){
        ID = identification_number;
        word = vocword;
        tense = vocabtense;
        definition = vocdef;
    }

    public String getWord(){
        return word;
    }

    public String getTense(){
        return tense;
    }

    public String getDefinition(){
        return  definition;
    }

    public int getID(){
        return ID;
    }

    @Override
    public String toString(){
        String toPrint ="ID: " + ID + " Word: " + word + " Tense: " + tense + " Definition: " + definition;
        return toPrint;
    }
}
