package com.finale.notewordy;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class Dictionary extends AppCompatActivity {
    public static ArrayList<String> vocword = new ArrayList<String>();
    public static ArrayList<String> voctense = new ArrayList<String>();
    public static ArrayList<String> vocdef = new ArrayList<String>();
    public static final String DICTIONARY_CHECKPOINT = "LAST_WORD_SEEN_IN_DICTIONARY";
    private TextView wordView;
    private TextView tenseView;
    private TextView defView;
    private int currID = 1;
    private dataHelper vocBase;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dictionary);
        Intent checkIn = getIntent();
        currID = checkIn.getIntExtra(MainActivity.STARTING_ID, 1);
        vocBase = new dataHelper(this);
        //grabDatabase();
        wordView = (TextView) findViewById(R.id.wordTV);
        tenseView = (TextView) findViewById(R.id.tenseTV);
        defView = (TextView) findViewById(R.id.defTV);
        setTextViews();
    }

    private void grabDatabase() {
        Cursor result = vocBase.getT1Data();
        while (result.moveToNext()){
            vocword.add(result.getString(result.getColumnIndex(vocBase.COL_2)));
            voctense.add(result.getString(result.getColumnIndex(vocBase.COL_3)));
            vocdef.add(result.getString(result.getColumnIndex(vocBase.COL_4)));
        }
    }

    private void setTextViews(){
        wordView.setText(vocword.get(currID-1));
        tenseView.setText(voctense.get(currID-1));
        defView.setText(vocdef.get(currID-1));
    }

    public void prevWord(View view) {
        if(currID != 1){
            currID--;
            setTextViews();
        }
    }

    public void nxtWord(View view) {
        if(currID < vocword.size()){
            currID++;
            setTextViews();
        }
    }

    public void lastScreen(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void firstSkip(View view) {
        currID = 1;
        setTextViews();
    }

    public void lastSkip(View view) {
        currID = vocword.size();
        setTextViews();
    }

    public void toSearch(View view) {
        Intent intent = new Intent(this, SearchDictionary.class);
        intent.putExtra(DICTIONARY_CHECKPOINT, currID);
        startActivity(intent);
    }
}
