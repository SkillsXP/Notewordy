package com.finale.notewordy;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Random;

public class dailyWord extends AppCompatActivity {
    private ArrayList<String> vocword = new ArrayList<String>();
    private ArrayList<String> voctense = new ArrayList<String>();
    private ArrayList<String> vocdef = new ArrayList<String>();
    private dataHelper vocBase;
    public static final String DAILY_ID = "WORD_OF_THE_DAY_ID";
    private int dailyID = 58;
    private TextView wordView;
    private TextView tenseView;
    private TextView defView;
    private SharedPreferences datePref;
    private SharedPreferences.Editor editDate;
    private String currdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        datePref = getSharedPreferences(MainActivity.DATE_FILE, Context.MODE_PRIVATE);
        editDate = datePref.edit();
        currdate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        setContentView(R.layout.activity_daily_word);
        vocBase = new dataHelper(this);
        grabDatabase();
        setDailyID();
        wordView = (TextView) findViewById(R.id.wordTV);
        tenseView = (TextView) findViewById(R.id.tenseTV);
        defView = (TextView) findViewById(R.id.defTV);
        setTextViews();
    }

    private void grabDatabase() {
        Cursor result = vocBase.getT1Data();
        while (result.moveToNext()){
            vocword.add(result.getString(result.getColumnIndex(vocBase.COL_2)));
            voctense.add(result.getString(result.getColumnIndex(vocBase.COL_3)));
            vocdef.add(result.getString(result.getColumnIndex(vocBase.COL_4)));
        }
    }

    private void setTextViews(){
        wordView.setText(vocword.get(dailyID-1));
        tenseView.setText(voctense.get(dailyID-1));
        defView.setText(vocdef.get(dailyID - 1));
    }

    public void toMain(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra(MainActivity.STARTING_ID, dailyID);
        startActivity(intent);
    }

    public void toDictionary(View view) {
        Intent intent = new Intent(this, Dictionary.class);
        intent.putExtra(MainActivity.STARTING_ID, dailyID);
        Dictionary.vocword = vocword;
        Dictionary.voctense = voctense;
        Dictionary.vocdef = vocdef;
        startActivity(intent);
    }

    public void setDailyID() {
        String lastDate = datePref.getString(MainActivity.DATE_KEY, "");
        if (!(lastDate.equals(currdate))){
            editDate.remove(MainActivity.DATE_KEY);
            editDate.commit();
            editDate.putString(MainActivity.DATE_KEY, currdate);
            editDate.commit();
            editDate.remove(DAILY_ID);
            editDate.commit();
            editDate.putInt(DAILY_ID, randomizeID());
            editDate.commit();
        }
        dailyID = datePref.getInt(DAILY_ID, 58);
    }

    private int randomizeID() {
        Random rand = new Random();
       return rand.nextInt(vocword.size());
    }
}
