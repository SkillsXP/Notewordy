package com.finale.notewordy;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class SearchDictionary extends AppCompatActivity {

    int lastWordIndex = 1;
    AutoCompleteTextView editMe;
    ArrayAdapter<String> vocabwords;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent checkpoint = getIntent();
        lastWordIndex = checkpoint.getIntExtra(Dictionary.DICTIONARY_CHECKPOINT, 1);
        setContentView(R.layout.activity_search_dictionary);
        vocabwords = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, Dictionary.vocword);
        editMe = (AutoCompleteTextView) findViewById(R.id.edit_message);
        editMe.getBackground().setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_IN);
        editMe.setAdapter(vocabwords);
        editMe.setOnKeyListener(new View.OnKeyListener(){
            @Override
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                if ((event.getAction() == KeyEvent.ACTION_DOWN) && (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    searchDictionary(v);
                    return true;
                }
                return false;
            }
        });
    }

    public void searchDictionary(View view) {
        String search = editMe.getText().toString().toLowerCase();
        int index = -1;
        for (int k = 0; k < Dictionary.vocword.size(); k++) {
            if (search.equals(Dictionary.vocword.get(k).toLowerCase())) {
                index = k;
            }
        }
        if (index != -1) {
            index += 1;
            Intent intent = new Intent(this, Dictionary.class);
            intent.putExtra(MainActivity.STARTING_ID, index);
            startActivity(intent);
        }
        else {
            editMe.setHint("Not in dictionary.");
            editMe.setText("");
        }
    }

    public void toDictionaryfromSearch(View view) {
        Intent intent = new Intent(this, Dictionary.class);
        intent.putExtra(MainActivity.STARTING_ID, lastWordIndex);
        startActivity(intent);
    }
}
