package com.finale.notewordy;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by shreyas on 5/21/16.
 */

public class dataHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME= "vocabWords.db";
    public static final String TABLE_1 = "unused_words";
    public static final String TABLE_2 = "used_words";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "WORD";
    public static final String COL_3 = "TENSE";
    public static final String COL_4 = "DEFINITION";

     public dataHelper(Context context) {
         super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_1 + " (" + COL_1 + " INTEGER PRIMARY KEY AUTOINCREMENT," + COL_2 + " TEXT," + COL_3 + " TEXT," + COL_4 + " TEXT)");
        db.execSQL("CREATE TABLE " + TABLE_2 + " (" + COL_1 + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COL_2 + " TEXT," + COL_3 + " TEXT," + COL_4 + " TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP IF EXISTS " + TABLE_1);
        db.execSQL("DROP IF EXISTS " + TABLE_2);
        onCreate(db);
    }

    public boolean insertDataUnused(String word, String tense, String definition){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_2, word);
        cv.put(COL_3, tense);
        cv.put(COL_4, definition);
        long validity = db.insert(TABLE_1, null, cv);
        if (validity == -1){
            return false;
        }
        else{
            return true;
        }
    }

    public boolean insertDataUsed(String word, String tense, String definition){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_2, word);
        cv.put(COL_3, tense);
        cv.put(COL_4, definition);
        long validity = db.insert(TABLE_2, null, cv);
        if (validity == -1){
            return false;
        }
        else{
            return true;
        }
    }

    public Cursor getT1Data(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor allData = db.rawQuery("select * from " + TABLE_1, null);
        return allData;
    }

    public Cursor getT2Data(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor allData = db.rawQuery("select * from " + TABLE_2, null);
        return allData;
    }
}
