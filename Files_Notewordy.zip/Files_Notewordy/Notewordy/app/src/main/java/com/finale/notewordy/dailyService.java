package com.finale.notewordy;
import android.app.KeyguardManager;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.support.annotation.Nullable;
import android.os.Handler;
import android.os.Process;

/**
 * Created by bluejay on 5/25/16.
 */
/**
 * To do:
 * 1.) Find a way to store data permanently, and
 * create a boolean that checks whether or not the user has seen the word of the day once
 * 2.) Figure out what to do with thread
 * 3.) In ServiceHandler, write code that does work based on whether there is a lockscreen
 * 4.) Buttons to move on from activity (Do on real app)
 * 5.) Figure out how to actually have the receiver check for broadcasts
 */

public class dailyService extends Service {
    private Looper mainLooper;
    private Handler mHandler;
    private ActionReceiver ar;

    //This class is to create an alternate thread for the service to use
   /* private final class ServiceHandler extends Handler {
    *    public ServiceHandler(Looper looper) {
    *        super(looper);
    *    }
    * }
    */
    //This class is to receive ACTION_USER_PRESENT or ACTION_USER_PRESENT
    private final class ActionReceiver extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Intent.ACTION_SCREEN_ON) && !(lockscreen())){
                //Starts MainActivity class
                Intent startUp = new Intent(context, MainActivity.class);
                startActivity(startUp);
            }
            else if (intent.getAction().equals(Intent.ACTION_USER_PRESENT)){
                //Starts MainActivity class
                Intent startUp = new Intent(context, MainActivity.class);
                startActivity(startUp);
            }
        }
    }

    @Override
    public void onCreate() {
        HandlerThread thread = new HandlerThread("toStartThread", Process.THREAD_PRIORITY_BACKGROUND);
        thread.start();
        mainLooper = thread.getLooper();
        mHandler = new Handler(mainLooper);
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_USER_PRESENT);
        ar = new ActionReceiver();
        registerReceiver(ar, filter, null, mHandler);
    }
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
       /* Message msg = mHandler.obtainMessage();
        msg.arg1 = startId;
        mHandler.sendMessage(msg);
        */
        return START_STICKY;
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(ar);
        stopSelf();
    }

    private boolean lockscreen(){
        //requires API level 22
        //checks if there is a lockscreen
        KeyguardManager locker = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
        return locker.isDeviceLocked();
    }
}