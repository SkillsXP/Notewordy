package com.finale.notewordy;
import android.app.KeyguardManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by bluejay on 5/25/16.
 */

//Starts service on Bootup
public class BootReceiver extends BroadcastReceiver {
    private boolean learnt = false;
    private final class ActionReceiver extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(Intent.ACTION_SCREEN_ON) && !(learnt) && !(lockscreen(context))){
                //Starts MainActivity class
                learnt = true;
                Intent startUp = new Intent(context, MainActivity.class);
                context.startActivity(startUp);
            }
            else if (intent.getAction().equals(Intent.ACTION_USER_PRESENT) && !(learnt)){
                //Starts MainActivity class
                learnt = true;
                Intent startUp = new Intent(context, MainActivity.class);
                context.startActivity(startUp);
            }
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        Intent serviceBoot = new Intent(context, dailyService.class);
        context.startService(serviceBoot);
       /* IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_SCREEN_ON);
        filter.addAction(Intent.ACTION_USER_PRESENT);
        ActionReceiver ar = new ActionReceiver();
        context.registerReceiver(ar, filter);
        */
    }

    private boolean lockscreen(Context context){
        //requires API level 22
        //checks if there is a lockscreen
        KeyguardManager locker = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE);
        return locker.isDeviceLocked();
    }
}